"""Development entry point.  For production see DEPLOYMENT.md."""
import uvicorn
if __name__ == "__main__":
    uvicorn.run("app.main:app", host="127.0.0.1", port=8080, reload=False)
